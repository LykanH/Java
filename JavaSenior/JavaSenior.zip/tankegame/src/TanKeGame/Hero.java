package TanKeGame;

/**
 * @author muchen
 * @create 2022 - 09 - 2022/9/2 22:18
 */
public class Hero extends TanKe{

    public Hero(int x, int y) {
        super(x, y);
    }
}
