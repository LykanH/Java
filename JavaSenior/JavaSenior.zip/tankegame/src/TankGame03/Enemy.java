package TankGame03;

/**
 * @author muchen
 * @create 2022 - 09 - 2022/9/4 15:40
 */
public class Enemy extends TanKe {

    public Enemy(int x, int y, int direct) {
        super(x, y, direct);
    }

}
