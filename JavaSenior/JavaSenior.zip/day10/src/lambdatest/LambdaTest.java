package lambdatest;

/**
 * @author muchen
 * @create 2022 - 12 - 2022/12/20 16:13
 */
public class LambdaTest {

}
